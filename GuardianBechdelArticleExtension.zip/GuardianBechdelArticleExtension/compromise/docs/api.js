module.exports = {
  generic: require('./generic'),

  subsets: require('./subsets')
};
